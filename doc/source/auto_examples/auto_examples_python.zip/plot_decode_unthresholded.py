# emacs: -*- mode: python-mode; py-indent-offset: 4; tab-width: 4; indent-tabs-mode: nil -*-
# ex: set sts=4 ts=4 sw=4 et:
"""

.. _dec4:

========================================
 Decode unthresholded map
========================================

An example of decode.Decoder.decode_continuous.

"""
###############################################################################
# Start with the necessary imports
# --------------------------------
from os.path import join
import matplotlib.pyplot as plt

import nibabel as nib
from nilearn import plotting

from gclda.model import Model
from gclda.decode import Decoder
from gclda.utils import get_resource_path

###############################################################################
# Load model and initialize decoder
# ----------------------------------
model_file = join(get_resource_path(), 'models/model_Neurosynth2015Filtered2_temp.pklz')
model = Model.load(model_file)
decoder = Decoder(model)

###############################################################################
# Read in image to decode
# --------------------------------------
file_to_decode = 'data/faces_specificity_z.nii.gz'
img_to_decode = nib.load(file_to_decode)
fig = plotting.plot_stat_map(img_to_decode, display_mode='z',
                             threshold=3.290527,
                             cut_coords=[-28, -4, 20, 50])

###############################################################################
# Decode ROI
# -----------
df, topic_weights = decoder.decode_continuous(img_to_decode)

###############################################################################
# Get associated terms
# ---------------------
df = df.sort_values(by='Weight', ascending=False)
print(df.head(10))

###############################################################################
# Plot topic weights
# ------------------
fig2, ax2 = plt.subplots()
ax2.plot(topic_weights)
ax2.set_xlabel('Topic #')
ax2.set_ylabel('Weight')
fig2.show()
